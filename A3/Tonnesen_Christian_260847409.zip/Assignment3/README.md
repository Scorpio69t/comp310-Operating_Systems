Christian Tonnesen: 260847409

Comments:
I print any contents within an evicted frame, so long as it is at least partially full. Empty lines are not skipped and just print "none"

See here for partial frame: https://edstem.org/us/courses/16123/discussion/1333997
See here for printing "none" on empty lines: https://edstem.org/us/courses/16123/discussion/1344962