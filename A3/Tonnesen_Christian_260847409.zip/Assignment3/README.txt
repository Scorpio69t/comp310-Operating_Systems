public testcase notes:

tc1 tc2 intention: 
                   testing exec command, there is no page fault in this test case, 
                   each program only have two pages max.

tc3 intention: 
             testing exec command, page fault involved, when using this test case, 
             make sure there are fewer frames than file's pages.

tc4 intention: 
               testing exec command. This is the most complex test case, 
               make sure there are fewer frames than file's pages.

tc5 intention: 
              testing run command.