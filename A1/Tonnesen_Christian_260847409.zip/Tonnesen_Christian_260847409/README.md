Christian Tonnesen: 260847409

Comments:
Utilizes provided starter code
my_ls uses ASCII sorting through qsort()