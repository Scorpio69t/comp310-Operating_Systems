Christian Tonnesen: 260847409

Comments:
Utilizes provided starter code
Strange behaviour with repeated calls of "run prog1", but it handled through an extra restriction in parseInput()
See here: https://edstem.org/us/courses/16123/discussion/1212925